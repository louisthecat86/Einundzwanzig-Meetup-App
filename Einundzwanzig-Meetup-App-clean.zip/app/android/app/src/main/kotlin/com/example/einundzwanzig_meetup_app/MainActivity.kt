package com.example.einundzwanzig_meetup_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
